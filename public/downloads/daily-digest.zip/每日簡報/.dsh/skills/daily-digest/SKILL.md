---
name: daily-digest
description: 把每日來源（RSS 資訊雷達、sessions digest）整理成一份可推送的簡報；維護 digest dashboard 的版型與配色；盯排程有沒有真的跑、有沒有失敗；盯來源清單有沒有失效
---

# daily-digest

> 這個場景專屬的技能：只有 `每日簡報` 場景看得到。
> 別的場景連清單裡都不會有它。

## 做法

（把這場景特有的做法寫在這裡。references/ 放較長的參考資料，
scripts/ 放可執行的腳本。單篇上限 12 KB，超了拆主檔＋子檔。）
