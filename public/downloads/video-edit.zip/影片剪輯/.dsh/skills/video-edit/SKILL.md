---
name: video-edit
description: 把旁白稿變成可交付的 MP4 —— 配音、節奏（beats）、字幕、動效、HyperFrames 渲染、REVIEW 驗收
---

# video-edit

> 這個場景專屬的技能：只有 `影片剪輯` 場景看得到。
> 別的場景連清單裡都不會有它。

## 做法

（把這場景特有的做法寫在這裡。references/ 放較長的參考資料，
scripts/ 放可執行的腳本。單篇上限 12 KB，超了拆主檔＋子檔。）
