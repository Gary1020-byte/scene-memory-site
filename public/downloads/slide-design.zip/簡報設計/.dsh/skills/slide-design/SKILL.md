---
name: slide-design
description: 把素材檔（content.md）變成有品牌感的簡報／報告頁（HTML）
---

# slide-design

> 這個場景專屬的技能：只有 `簡報設計` 場景看得到。
> 別的場景連清單裡都不會有它。

## 做法

（把這場景特有的做法寫在這裡。references/ 放較長的參考資料，
scripts/ 放可執行的腳本。單篇上限 12 KB，超了拆主檔＋子檔。）
