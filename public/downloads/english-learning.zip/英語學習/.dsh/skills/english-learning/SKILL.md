---
name: english-learning
description: 讀線（分級文章＋生字）＋說線（影子跟讀＋WER）的每日場景 —— 難度校準、逐段教、記生字、算 WER，寫進場景私有記憶的 §₀ 交接
---

# english-learning

> 這個場景專屬的技能：只有 `英語學習` 場景看得到。
> 別的場景連清單裡都不會有它。

## 做法

（把這場景特有的做法寫在這裡。references/ 放較長的參考資料，
scripts/ 放可執行的腳本。單篇上限 12 KB，超了拆主檔＋子檔。）
