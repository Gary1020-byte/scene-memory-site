---
name: kol-content
description: 維護 KOL 聲調與格式規範、把「選題卡」寫成可發布成品（X 貼文／thread／IG 文案／長文）
---

# kol-content

> 這個場景專屬的技能：只有 `內容創作` 場景看得到。
> 別的場景連清單裡都不會有它。

## 做法

（把這場景特有的做法寫在這裡。references/ 放較長的參考資料，
scripts/ 放可執行的腳本。單篇上限 12 KB，超了拆主檔＋子檔。）
