---
name: recipe
description: 食譜資料庫的建檔、攝入、更新、查詢 —— 每道菜一頁 Markdown＋結構化 frontmatter，食材頁雙向 wikilink，依現有食材與時間難度挑菜
---

# recipe

> 這個場景專屬的技能：只有 `食譜` 場景看得到。
> 別的場景連清單裡都不會有它。

## 做法

（把這場景特有的做法寫在這裡。references/ 放較長的參考資料，
scripts/ 放可執行的腳本。單篇上限 12 KB，超了拆主檔＋子檔。）
