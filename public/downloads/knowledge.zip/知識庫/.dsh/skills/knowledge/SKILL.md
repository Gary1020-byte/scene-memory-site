---
name: knowledge
description: 知識的存與取 —— Obsidian 與 LLM-Wiki 的寫入、查證、敘事化文件
---

# knowledge

> 這個場景專屬的技能：只有 `知識庫` 場景看得到。
> 別的場景連清單裡都不會有它。

## 做法

（把這場景特有的做法寫在這裡。references/ 放較長的參考資料，
scripts/ 放可執行的腳本。單篇上限 12 KB，超了拆主檔＋子檔。）
