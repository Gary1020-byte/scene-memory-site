---
name: dev
description: 寫程式、除錯、跑測試、把外部 coding agent（Claude Code／Codex／OpenCode）編排起來 —— 從需求到可合併的 diff
---

# dev

> 這個場景專屬的技能：只有 `開發工具` 場景看得到。
> 別的場景連清單裡都不會有它。

## 做法

（把這場景特有的做法寫在這裡。references/ 放較長的參考資料，
scripts/ 放可執行的腳本。單篇上限 12 KB，超了拆主檔＋子檔。）
