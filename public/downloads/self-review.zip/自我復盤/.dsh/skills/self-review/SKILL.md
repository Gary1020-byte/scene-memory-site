---
name: self-review
description: 预览 + 文件库 + AI —— 周报、复盘、资料歸檔
---

# self-review

> 這個場景專屬的技能：只有 `自我復盤` 場景看得到。
> 別的場景連清單裡都不會有它。

## 做法

（把這場景特有的做法寫在這裡。references/ 放較長的參考資料，
scripts/ 放可執行的腳本。單篇上限 12 KB，超了拆主檔＋子檔。）
