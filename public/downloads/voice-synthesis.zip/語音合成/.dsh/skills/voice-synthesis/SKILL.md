---
name: voice-synthesis
description: 文字轉語音（MiniMax TTS 主力 + edge-tts 備援）、哼唱/歌唱人聲、人聲分軌與混音對齊、音訊後處理與實測驗證
---

# voice-synthesis

> 這個場景專屬的技能：只有 `語音合成` 場景看得到。
> 別的場景連清單裡都不會有它。

## 做法

（把這場景特有的做法寫在這裡。references/ 放較長的參考資料，
scripts/ 放可執行的腳本。單篇上限 12 KB，超了拆主檔＋子檔。）
