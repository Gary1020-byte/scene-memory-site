---
name: kol-publish
description: 維護 X／Instagram／網站三通道發布管線狀態、發布前通道合規檢查、發布回執與失敗重試建議
---

# kol-publish

> 這個場景專屬的技能：只有 `社群發布` 場景看得到。
> 別的場景連清單裡都不會有它。

## 做法

（把這場景特有的做法寫在這裡。references/ 放較長的參考資料，
scripts/ 放可執行的腳本。單篇上限 12 KB，超了拆主檔＋子檔。）
